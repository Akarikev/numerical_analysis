INDEX NUMBER : PS/CSC/19/044
The files non_linear_eqns.py and nonLinearEquations.py are the same thing, one is for test cases the other 
is for reading values respectively
