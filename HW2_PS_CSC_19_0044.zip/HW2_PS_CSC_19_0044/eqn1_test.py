import math

# Test function 1: f(x) = x - cos(x)
def equation1(x):
    return x - math.cos(x)

def equation1_derivative(x):
    return 1 + math.sin(x)
