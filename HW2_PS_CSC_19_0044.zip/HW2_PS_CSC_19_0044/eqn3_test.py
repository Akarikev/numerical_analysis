# Test function 3: f(x) = x^4 - 7.4x^3 + 20.44x^2 - 24.184x + 9.6448
def equation3(x):
    return x**4 - 7.4*x**3 + 20.44*x**2 - 24.184*x + 9.6448

def equation3_derivative(x):
    return 4*x**3 - 22.2*x**2 + 40.88*x - 24.184
