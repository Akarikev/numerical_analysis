import math

# Test function 2: f(x) = e^(-x) - x
def equation2(x):
    return math.exp(-x) - x

def equation2_derivative(x):
    return -math.exp(-x) - 1
